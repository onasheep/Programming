﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20230620_practice
{
    public class GamePlay
    {
        int p_Y = 2;
        int p_X = 2;
        string[,] myMap;
        List<string[,]> mapList;
        List<int> prevPortalY;
        List<int> prevPortalX;
        int[] portalPosY;
        int[] portalPosX;

      
        public void Play()
        {

            MapMaker map = new MapMaker();

            // 맵 초기화 

            map.Init();
            myMap = map.board;

            Init(myMap);

            // 맵 담기



            while (true)
            {
                mapList.Add(myMap);

                map.Init();
                Init(mapList[0]);


                while (true)
                {
                    DrawBoard(myMap);

                    MovePlayer(myMap, ref p_Y, ref p_X);
                    Console.WriteLine("{0}", p_Y);
                    Console.WriteLine("{0}", p_X);
                    if (p_Y == portalPosY[1] && p_X == portalPosX[1])
                    {
                        myMap[p_Y, p_X] = "□";
                        mapList.Add(myMap);
                        p_Y = portalPosY[3];
                        p_X = portalPosX[3];
                        break;
                    }
                    Console.SetCursorPosition(0, 0);

                }
            }








        }

        public void Init(string[,] myMap)
        {
            mapList = new List<string[,]>();
            prevPortalY = new List<int>();
            prevPortalX = new List<int>();

            prevPortalY.Add(p_Y);
            prevPortalX.Add(p_X);
            // 시계방향 포탈 좌표
            portalPosY = new int[4] { 1, 6, 11, 6 };

            portalPosX = new int[4] { 6, 11, 6, 1 };
            Set_PlayerPos(myMap, prevPortalY, prevPortalX);


        }
        public void DrawBoard(string[,] myMap)
        {
            for (int i = 0; i < myMap.GetLength(0); i++)
            {
                for (int j = 0; j < myMap.GetLength(1); j++)
                {

                    Console.Write("{0}", myMap[i, j]);

                    Console.Write(" ");
                }
                Console.WriteLine();
                Console.WriteLine();

            }
        }

        public void Set_PlayerPos(string[,] myMap, List<int> prevPortalY, List<int> prevPortalX)
        {

            myMap[prevPortalY[0], prevPortalX[0]] = "▲";
            prevPortalY.Remove(0);
            prevPortalX.Remove(0);
        }

        public void InitPlayerPos(string[,] myMap)
        {
            Random rand = new Random();

            p_Y = rand.Next(3, myMap.GetLength(0) - 2);
            p_X = rand.Next(3, myMap.GetLength(1) - 2);

            while (true)
            {
                            Console.WriteLine("!");

                if (myMap[p_Y, p_X] == "□")
                {
                    myMap[p_Y, p_X] = "▲";
                    break;
                }

            }
        }
        // 인풋
        public void MovePlayer(string[,] myMap,ref int p_Y, ref int p_X)
        {
            ConsoleKeyInfo input = Console.ReadKey();

            switch (input.Key)
            {
                case ConsoleKey.W:
                case ConsoleKey.UpArrow:

                    if (p_Y > 1 && myMap[p_Y - 1, p_X] != "▣")
                    {
                      
                        myMap[p_Y, p_X] = "□";
                        p_Y--;
                    }                    

                    myMap[p_Y, p_X] = "▲";


                    break;
                case ConsoleKey.S:
                case ConsoleKey.DownArrow:
                    if (p_Y < myMap.GetLength(0) - 2 && myMap[p_Y + 1, p_X] != "▣")
                    {
                        myMap[p_Y, p_X] = "□";
                        p_Y++;
                        
                    }
                    myMap[p_Y, p_X] = "▼";

                    break;
                case ConsoleKey.A:
                case ConsoleKey.LeftArrow:
                    if (p_X > 1 && myMap[p_Y , p_X - 1] != "▣")
                    {
                        myMap[p_Y, p_X] = "□";
                        p_X--;

                    }
                    myMap[p_Y, p_X] = "◀";

                    break;
                case ConsoleKey.D:
                case ConsoleKey.RightArrow:
                    if (p_X < myMap.GetLength(1) - 2 && myMap[p_Y , p_X + 1] != "▣")
                    {
                        myMap[p_Y, p_X] = "□";
                        p_X++;

                    }
                    myMap[p_Y, p_X] = "▶";
                    break;
            }
        }

    }
}

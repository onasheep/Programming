﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20230620_practice
{
    public class Program
    {



        static void Main(string[] args)
        {

            GamePlay gp = new GamePlay();

  
                gp.Play();



        }


    }
}

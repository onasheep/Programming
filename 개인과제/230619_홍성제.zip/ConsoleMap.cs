﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20230617_weekend_hw
{
    public class ConsoleMap
    {
        public void Init()
        {
            
        }

        public void DrawMap()
        {

        }

    }
}

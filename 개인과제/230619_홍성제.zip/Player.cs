﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20230617_weekend_hw
{
    public class Player
    {
        public int PPosCol { get; private set; } = 10;
        public int PPosRow { get; private set; } = 20;

    }
}
